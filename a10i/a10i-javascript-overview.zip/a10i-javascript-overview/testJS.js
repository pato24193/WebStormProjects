function hideImage() {
    document.getElementById("pigImage").style.display = "none";
}
