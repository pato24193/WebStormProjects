function turnOn() {
    document.getElementById('imgLight').src = 'img/pic_bulbon.gif';
}

function turnOff() {
    document.getElementById('imgLight').src = 'img/pic_bulboff.gif';
}
