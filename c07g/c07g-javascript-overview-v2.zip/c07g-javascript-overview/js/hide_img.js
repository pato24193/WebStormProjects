function hideImg() {
    document.getElementById("pigImg").style.display = "none";
}

function visibleImg() { //BEGIN
    document.getElementById("pigImg").style.display = "block";
} //END
