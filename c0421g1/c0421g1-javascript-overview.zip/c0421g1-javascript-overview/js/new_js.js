function displayImg() {
    document.getElementById("imgPig").style.display = "block";
}