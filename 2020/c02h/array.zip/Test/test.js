// 1. cú pháp

function tenHam(thamSoNeuCo) {
    // khoi lenh
}

function isPrimeNumber(number) {
    let count = 0;

    for (let i = 1; i <= number; i++) {
        if (number % i == 0) {
            // count = count + 1;
            count++;
        }
    }

    if (count == 2) {
        return true;
    }

    return false;
}

// 1.a. Su dung ham
// for (let num = 1; num <= 100; num++) {
//     if (isPrimeNumber(num)) {
//         document.writeln(num);
//     }
// }

// 1.b. Khong su dung ham
// let count = 0;
// for (let num = 1; num <= 100; num++) {
//     count = 0;
//     // check so nguyen to
//     for (let j = 1; j <= num; j++) {
//         if (num % j == 0) {
//             count++;
//         }
//     }
//
//     if (count == 2) {
//         document.writeln(num);
//     }
// }

// 2. mục đích sử dụng hàm
// - Code ro rang, tuong minh
// - Chia nho source code thanh tung module, thuan tien cho viec xu ly

// 3. Tham tri, tham chieu là gì
let a = 1;
let b = 200;

// function swap(number1, number2) {
//     // number1 = 1, number = 200;
//     let middle = number1;
//     number1 = number2;
//     number2 = middle;
//
//     document.writeln("In function: " + number1 + " " + number2 + "<br>");
// }
//
// document.writeln("Before function: " + a + " " + b + "<br>");
// swap(a, b);
// document.writeln("After function: " + a + " " + b + "<br>");

// function swap2(numberArray) {
//     let middle = numberArray[0];
//     numberArray[0] = numberArray[1];
//     numberArray[1] = middle;
//
//     document.writeln("In function: " + numberArray[0] + " " + numberArray[1] + "<br>");
// }
//
// let aBArray = [a, b];
// document.writeln("Before function: " + aBArray[0] + " " + aBArray[1] + "<br>");
// swap2(aBArray);
// document.writeln("After function: " + aBArray[0] + " " + aBArray[1] + "<br>");

// 4. return

// return 3;
// return false;
// return a;

function checkReturn() {
    document.write("a" + "<br>");
    return;
    document.write("b" + "<br>");
    document.write("c" + "<br>");
}

checkReturn();