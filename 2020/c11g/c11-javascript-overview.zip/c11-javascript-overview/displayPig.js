function displayPig() {
    document.getElementById("pigImage").style.display = "block";
}
