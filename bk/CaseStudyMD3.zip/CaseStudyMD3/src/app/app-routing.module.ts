import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { EmployeeListComponent } from './components/employees/employee-list/employee-list.component';
import { CommonModule } from '@angular/common';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {FormsModule } from '@angular/forms';


const routes: Routes = [
  {path: '',component:HomeComponent},
  {path: 'employee-list',component:EmployeeListComponent},


  {path: '**',component:PageNotFoundComponent},
];

@NgModule({
  declarations:[HomeComponent, PageNotFoundComponent, EmployeeListComponent],
  imports: [RouterModule.forRoot(routes),CommonModule,Ng2SearchPipeModule,FormsModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
